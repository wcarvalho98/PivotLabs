package com.ufrpe.br.pivotlabs.about.presenter

class AboutPresenter {
}