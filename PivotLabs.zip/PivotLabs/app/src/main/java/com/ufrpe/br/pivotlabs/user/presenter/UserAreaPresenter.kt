package com.ufrpe.br.pivotlabs.user.presenter

class UserAreaPresenter {
}