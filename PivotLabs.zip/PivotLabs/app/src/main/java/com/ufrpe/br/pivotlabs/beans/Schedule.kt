package com.ufrpe.br.pivotlabs.beans

data class Schedule(var dayWeek: Int, var start: String, var end: String)