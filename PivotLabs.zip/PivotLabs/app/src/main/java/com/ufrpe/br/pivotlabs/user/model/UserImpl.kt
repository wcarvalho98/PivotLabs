package com.ufrpe.br.pivotlabs.user.model

class UserImpl {
}