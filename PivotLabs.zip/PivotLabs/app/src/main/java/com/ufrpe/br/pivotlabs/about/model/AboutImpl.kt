package com.ufrpe.br.pivotlabs.about.model

class AboutImpl {
}