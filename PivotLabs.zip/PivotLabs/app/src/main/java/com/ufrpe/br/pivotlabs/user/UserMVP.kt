package com.ufrpe.br.pivotlabs.user

interface UserMVP {
}