package com.ufrpe.br.pivotlabs.about

interface AboutMVP {
}