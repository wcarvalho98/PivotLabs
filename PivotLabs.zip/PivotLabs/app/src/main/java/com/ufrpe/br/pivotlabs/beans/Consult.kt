package com.ufrpe.br.pivotlabs.beans

data class Consult(var patient: String, var doctor: String, var start: String, var end: String)